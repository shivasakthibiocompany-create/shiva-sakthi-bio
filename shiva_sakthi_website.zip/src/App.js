import React from 'react';
import logo from './assets/logo.png';

function App() {
  return (
    <div className="font-georgia bg-white text-gray-900">
      <header className="bg-blue-900 text-white shadow-md flex items-center justify-between p-4">
        <div className="flex items-center space-x-2">
          <img src={logo} alt="Shiva Sakthi Bio Company Logo" className="h-12 w-auto" />
          <h1 className="text-2xl font-bold">Shiva Sakthi Bio Company</h1>
        </div>
        <nav className="space-x-4">
          <a href="#home" className="hover:underline">Home</a>
          <a href="#about" className="hover:underline">About</a>
          <a href="#products" className="hover:underline">Products</a>
          <a href="#gallery" className="hover:underline">Gallery</a>
          <a href="#contact" className="hover:underline">Contact</a>
        </nav>
      </header>
      <main>
        <section id="home" className="bg-cover bg-center h-screen flex items-center justify-center text-center text-white" style={{ backgroundImage: "url('/assets/hero.jpg')" }}>
          <div className="bg-black bg-opacity-50 p-8 rounded-xl">
            <h2 className="text-4xl font-bold">Growing Naturally, Serving Globally</h2>
            <p className="mt-4">Organic farming and vetiver-based products for a sustainable future</p>
          </div>
        </section>
      </main>
    </div>
  );
}

export default App;
